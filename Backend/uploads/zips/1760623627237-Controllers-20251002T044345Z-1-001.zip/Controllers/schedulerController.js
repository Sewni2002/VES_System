// controllers/schedulerController.js
const mongoose = require("mongoose");
const {
  Student,
  Y01_Sem01Stud,
  Y01_Sem02Stud,
  Y02_Sem01Stud,
  Y02_Sem02Stud,
  Y03_Sem01Stud,
  Y03_Sem02Stud,
} = require("../Model/Student");
const StudentAlt = require("../Model/StudentGrp"); // the 'Student' collection (StudentGrp.js)
const Group = require("../Model/Group");
const Scheduler = require("../Model/Scheduler");

// helper to normalize IDs
function normalize(s) {
  if (!s && s !== 0) return "";
  return String(s).replace(/[{}]/g, "").trim();
}

// 🔍 Search student across all collections (robust)
async function findStudent(studentID) {
  const norm = normalize(studentID);
  if (!norm) return null;

  // 1) Try main studentdb (Student model)
  let student = await Student.findOne({ studentID: norm });
  if (student) return student;

  // 2) Try semester tables (they may contain the student)
  const semesterModels = [
    Y01_Sem01Stud,
    Y01_Sem02Stud,
    Y02_Sem01Stud,
    Y02_Sem02Stud,
    Y03_Sem01Stud,
    Y03_Sem02Stud,
  ];
  for (const M of semesterModels) {
    try {
      const sem = await M.findOne({ $or: [{ studentID: norm }, { email: norm }] });
      if (sem) return sem;
    } catch (e) {
      // ignore and continue
    }
  }

  // 3) Finally try StudentAlt (the Student collection / StudentGrp)
  const alt = await StudentAlt.findOne({
    $or: [{ idNumber: norm }, { studentID: norm }, { name: norm }, { email: norm }],
  });
  if (alt) return alt;

  return null;
}

// GET viva schedule for student
exports.getVivaForStudent = async (req, res) => {
  try {
    const { sid } = req.params;
    const student = await findStudent(sid);

    if (!student) {
      return res.status(404).json({ error: "Student not found" });
    }

    // normalize group id: student may have groupID / groupId / gid
    let groupID = student.groupID || student.groupId || student.gid || null;

    // if groupId is an ObjectId (StudentGrp.groupId = ObjectId), resolve to group's gid
    if (!groupID && student.groupId && mongoose.Types.ObjectId.isValid(String(student.groupId))) {
      try {
        const groupDoc = await Group.findById(student.groupId);
        if (groupDoc && groupDoc.gid) groupID = groupDoc.gid;
      } catch (e) {
        // ignore
      }
    }

    if (!groupID) {
      return res.status(404).json({ error: "Group not assigned" });
    }

    // search scheduler with plain and brace-wrapped variants
    const variants = [groupID, `{${groupID}}`];
    const schedule = await Scheduler.findOne({ groupId: { $in: variants } });

    if (!schedule) {
      return res.status(404).json({ error: "Viva schedule not available yet" });
    }

    // success
    return res.json({
      studentID: student.studentID || student.idNumber || "",
      groupID,
      scheduler: schedule,
    });
  } catch (err) {
    console.error("getVivaForStudent error:", err);
    return res.status(500).json({ error: "Server error", details: err.message });
  }
};
