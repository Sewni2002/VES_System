// Controllers/submissionController.js
const fs = require("fs");
const path = require("path");
const Submission = require("../Model/Submission");
const StudentAlt = require("../Model/StudentGrp");
const { Student: PrimaryStudent } = require("../Model/Student");
const Group = require("../Model/Group");
const Deadline = require("../Model/Deadline");
const multer = require("multer");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage });

function normalize(s) {
  if (!s && s !== 0) return "";
  return String(s).replace(/[{}]/g, "").trim();
}

// ---------------- Helper: student+group lookup ----------------
async function getStudentAndGroup(rawStudentId) {
  const studentId = normalize(rawStudentId); 
  let student = null;

  try {
    if (PrimaryStudent) {
      student = await PrimaryStudent.findOne({
        $or: [
          { studentID: studentId },
          { email: studentId },
          { idNumber: studentId },
        ],
      });
    }
  } catch (e) {
    console.warn("PrimaryStudent lookup failed:", e);
  }

  if (!student) {
    student = await StudentAlt.findOne({
      $or: [
        { idNumber: studentId },
        { studentID: studentId },
        { name: studentId },
        { "members.studentID": studentId },
      ],
    });
  }

  if (!student) throw { status: 404, message: "Student not found" };

  const rawGid =
    student.gid || student.groupId || student.groupID || student.group || "";
  const gid = normalize(rawGid);
  if (!gid) throw { status: 404, message: `No group assigned for student ${studentId}` };

  const gidVariants = [gid, `{${gid}}`];
  let group = await Group.findOne({ gid: { $in: gidVariants } });

  if (group) {
    group = group.toObject();
  } else {
    group = {
      gid,
      groupName: student.groupName || student.name || `Group ${gid}`,
      members: student.members || [],
      assignedLocation: student.assignedLocation || "-",
      assignedDate: student.assignedDate || null,
      _id: null,
    };
  }

  // Role detection remains for reference
  let role = "member";
  if (Array.isArray(group.members) && group.members.length > 0) {
    const firstMemberId = normalize(group.members[0].studentID);
    role = studentId === firstMemberId ? "leader" : "member";
  }

  return { student, group, gid, role };
}

// ---------------- Deadline helpers ----------------
const getDeadline = async (req, res) => {
  try {
    const moduleCode = req.query.moduleCode || null;
    const query = { type: "submission" };
    if (moduleCode) query.moduleCode = moduleCode;

    const doc = await Deadline.findOne(query).sort({ endDate: -1 });
    if (!doc) return res.status(404).json({ error: "No deadline set" });
    return res.json({ endDate: doc.endDate });
  } catch (err) {
    console.error("getDeadline error:", err);
    return res.status(500).json({ error: "Server error fetching deadline" });
  }
};

async function checkDeadline(moduleCode = null) {
  const query = { type: "submission" };
  if (moduleCode) query.moduleCode = moduleCode;
  const doc = await Deadline.findOne(query).sort({ endDate: -1 });
  return doc ? new Date(doc.endDate) : null;
}

// ---------------- Submissions ----------------
const createTextSubmission = async (req, res) => {
  try {
    const studentID = req.params.studentID || req.body.studentID;
    if (!studentID) return res.status(400).json({ error: "studentID required" });

    const moduleCode = req.body.moduleCode || null;
    const deadline = await checkDeadline(moduleCode);
    if (deadline && Date.now() > deadline.getTime())
      return res.status(403).json({ error: "Submission deadline has passed" });

    const { languageType, scope, notes, file } = req.body;
    if (!file?.content)
      return res.status(400).json({ error: "Text file content required" });

    const { student, group, gid, role } = await getStudentAndGroup(studentID);

    const normalizedStudentId = normalize(
      student.studentID || student.idNumber || student.name
    );

    const findQuery = { groupID: gid, studentID: normalizedStudentId, type: "text" };
    if (moduleCode) findQuery.moduleCode = moduleCode;

    const update = {
      groupID: gid,
      groupObjectId: group._id || null,
      studentID: normalizedStudentId,
      studentName: student.name || student.iname || student.fname || "",
      role,
      type: "text",
      languageType,
      scope,
      notes,
      code: file.content,
      moduleCode: moduleCode || null,
      dateSubmit: Date.now(),
    };

    const submission = await Submission.findOneAndUpdate(findQuery, update, {
      new: true,
      upsert: true,
      setDefaultsOnInsert: true,
    });

    return res.status(201).json({ message: "Text submission saved", submission });
  } catch (err) {
    console.error("createTextSubmission error:", err);
    return res.status(err.status || 500).json({ error: err.message || "Server error" });
  }
};

// ---------------- Updated ZIP submission ----------------
const createZipSubmission = async (req, res) => {
  try {
    const studentID = req.body.studentID;
    if (!studentID) return res.status(400).json({ error: "studentID required" });

    const moduleCode = req.body.moduleCode || null;
    const deadline = await checkDeadline(moduleCode);
    if (deadline && Date.now() > deadline.getTime())
      return res.status(403).json({ error: "Submission deadline has passed" });

    const { student, group, gid, role } = await getStudentAndGroup(studentID);

    if (!req.files || req.files.length === 0)
      return res.status(400).json({ error: "At least one zip/rar file is required" });

    const savedSubmissions = [];
    for (const file of req.files) {
      const storageRel = path.join("uploads", file.filename);

      const submission = new Submission({
        groupID: gid,
        groupObjectId: group._id || null,
        studentID: normalize(student.studentID || student.idNumber || student.name),
        studentName: student.name || student.iname || student.fname || "",
        role,
        type: "zip",
        zip: {
          originalName: file.originalname,
          storagePath: storageRel,
          mimeType: file.mimetype,
          size: file.size,
        },
        moduleCode: moduleCode || null,
        dateSubmit: Date.now(),
      });

      await submission.save();
      savedSubmissions.push(submission);
    }

    return res
      .status(201)
      .json({ message: "All zip submissions saved", submissions: savedSubmissions });
  } catch (err) {
    console.error("createZipSubmission error:", err);
    return res.status(err.status || 500).json({ error: err.message || "Server error" });
  }
};

const getGroupSubmissions = async (req, res) => {
  try {
    const gid = normalize(req.params.gid);
    const variants = [gid, `{${gid}}`];
    const submissions = await Submission.find({
      groupID: { $in: variants },
    }).sort({ dateSubmit: -1 });
    return res.json({ submissions });
  } catch (err) {
    console.error("getGroupSubmissions error:", err);
    return res.status(500).json({ error: "Server error fetching submissions" });
  }
};

const editSubmission = async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id);
    const studentID = req.body.studentID;
    if (!submission) return res.status(404).json({ error: "Not found" });

    if (normalize(submission.studentID) !== normalize(studentID))
      return res.status(403).json({ error: "Only uploader may edit" });

    const moduleCode = req.body.moduleCode || submission.moduleCode || null;
    const deadline = await checkDeadline(moduleCode);
    if (deadline && Date.now() > deadline.getTime())
      return res.status(403).json({ error: "Deadline passed. Cannot edit." });

    if (submission.type === "text") {
      const { languageType, scope, notes, file } = req.body;
      if (languageType) submission.languageType = languageType;
      if (scope) submission.scope = scope;
      if (notes !== undefined) submission.notes = notes;
      if (file?.content) submission.code = file.content;
      if (moduleCode) submission.moduleCode = moduleCode;
      await submission.save();
      return res.json({ message: "Submission updated", submission });
    }
    return res.status(400).json({ error: "Zip editing not supported" });
  } catch (err) {
    console.error("editSubmission error:", err);
    return res.status(500).json({ error: "Server error editing" });
  }
};

const deleteSubmission = async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id);
    const studentID = req.body.studentID || req.query.studentID;
    if (!submission) return res.status(404).json({ error: "Not found" });

    if (normalize(submission.studentID) !== normalize(studentID))
      return res.status(403).json({ error: "Only uploader may delete" });

    const moduleCode = submission.moduleCode || null;
    const deadline = await checkDeadline(moduleCode);
    if (deadline && Date.now() > deadline.getTime())
      return res.status(403).json({ error: "Deadline passed. Cannot delete." });

    if (submission.type === "zip" && submission.zip?.storagePath) {
      try {
        const abs = path.resolve(submission.zip.storagePath);
        if (fs.existsSync(abs)) fs.unlinkSync(abs);
      } catch (e) {
        console.warn("Could not delete zip file:", e);
      }
    }

    await Submission.findByIdAndDelete(submission._id);
    return res.json({ message: "Submission deleted" });
  } catch (err) {
    console.error("deleteSubmission error:", err);
    return res.status(500).json({ error: "Server error deleting" });
  }
};

module.exports = {
  createTextSubmission,
  createZipSubmission,
  getGroupSubmissions,
  editSubmission,
  deleteSubmission,
  getDeadline,
  upload,
};
