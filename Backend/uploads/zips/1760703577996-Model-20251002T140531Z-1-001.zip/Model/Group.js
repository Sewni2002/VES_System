const mongoose = require('mongoose');

const groupSchema = new mongoose.Schema({
  groupName: String,
  members: [
    {
      studentID: { type: String, required: true },
      name: { type: String, required: true }
    }
  ],
  assignedDate: Date,
  assignedLocation: String,
  gid: { type: String, required: true, unique: true }
});

module.exports = mongoose.model('Group', groupSchema);
