// Model/Submission.js
const mongoose = require("mongoose");

const ZipMetaSchema = new mongoose.Schema({
  originalName: String,
  storagePath: String, // relative path like "uploads/12345-file.zip"
  mimeType: String,
  size: Number,
});

const submissionSchema = new mongoose.Schema({
  groupID: { type: String, required: true, index: true }, // gid string like "G104"
  groupObjectId: { type: mongoose.Schema.Types.ObjectId, ref: "Group", default: null },
  studentID: { type: String, required: true }, // this comes from StudentGrp.idNumber
  studentName: { type: String },
  role: { type: String, enum: ["leader", "member"], required: true },
  type: { type: String, enum: ["text", "zip"], required: true },
  languageType: { type: String },
  scope: { type: String }, // frontend/backend
  notes: { type: String },
  code: { type: String }, // stores text submission
  zip: ZipMetaSchema,

  moduleCode: { type: String, index: true, default: null }, // NEW: tie submission to a module to pick deadline

  dateSubmit: { type: Date, default: Date.now, index: true },
  updatedAt: { type: Date, default: Date.now },
  questionGenerate: { type: Boolean, default: false },
});

// Auto update updatedAt before save
submissionSchema.pre("save", function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model("StudentSubmission", submissionSchema);
