const mongoose = require('mongoose');

const InstructorUnavailabilitySchema = new mongoose.Schema({
  instructorName: String,
  fromDate: Date,
  toDate: Date,
  reason: String
});

module.exports = mongoose.model('InstructorUnavailability', InstructorUnavailabilitySchema);
