const mongoose = require('mongoose');

const SchedulerSchema = new mongoose.Schema({
  groupId: String,
  groupTopic: String,
  groupMembers: [String],
  scheduledDateTime: Date,
  instructorName: String,
  hallNumber: String,
  notes: String,
  substituteInstructor: String
});

module.exports = mongoose.model('Scheduler', SchedulerSchema);
