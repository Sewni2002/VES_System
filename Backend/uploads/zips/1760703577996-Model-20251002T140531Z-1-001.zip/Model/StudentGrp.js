const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  idNumber: String,
  name: String,
  groupId: { type: mongoose.Schema.Types.ObjectId, ref: 'Group' },
  topic: String,
  gid: String,
  members: [
    {
      studentID: { type: String, required: true },
      name: { type: String, required: true }
    }
  ],
  assignedLocation: String
});

module.exports = mongoose.model('Student', studentSchema, 'Student');
